`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063

module secure_router_tb;
    reg [5:0] d_in;
    wire [6:0] d_out0;
    wire [6:0] d_out1;
    wire [6:0] d_out2;
    wire [6:0] d_out3;
	
    secure_router uut (
        .in(d_in),
        .out0(d_out0),
        .out1(d_out1),
        .out2(d_out2),
        .out3(d_out3)
    );

    initial begin
        $monitor($time, " Input_stream = %b, Output_stream0 = %b, Output_stream1 = %b, Output_stream2 = %b, Output_stream3 = %b ", d_in, d_out0, d_out1, d_out2, d_out3);
        d_in = 6'b111011;
        #100;
        d_in = 6'b000101;
        #100;
        d_in = 6'b101110;
        #100;
        d_in = 6'b100010;
        #100;
        d_in = 6'b011110;
        #100;
        $finish; // End the simulation
    end
endmodule
