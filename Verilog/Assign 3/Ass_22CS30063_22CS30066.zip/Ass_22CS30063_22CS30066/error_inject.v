`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063

module error_inject (
    input [6:0] d_orig,
    input [1:0] erpos,
    output reg [6:0] d_error,
	 input clk
);
always @(posedge clk) begin
    d_error <= d_orig;
    d_error[erpos] <= ~d_error[erpos];
end
endmodule
