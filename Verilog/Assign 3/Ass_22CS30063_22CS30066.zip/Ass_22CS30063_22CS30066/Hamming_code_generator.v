`timescale 1ns / 1ps

// GROUP 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063

module Hamming_code_generator(in, out);
input [3:0]in;
output [6:0] out;
wire [2:0]y;

xor g1(y[0], in[0], in[1]);
xor g2(out[0], y[0], in[3]);

xor g3(y[1], in[0], in[2]);
xor g4(out[1], y[1], in[3]);

assign out[2]=in[0];

xor g5(y[2], in[1], in[2]);
xor g6(out[3], y[2], in[3]);

assign out[4]=in[1];
assign out[5]=in[2];
assign out[6]=in[3];

endmodule
