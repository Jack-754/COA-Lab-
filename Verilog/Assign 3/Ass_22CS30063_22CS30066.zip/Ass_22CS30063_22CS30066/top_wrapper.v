`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063


module top_wrapper(
input clk_in,
input [5:0] d_in,
output [3:0] d_disp0,
output [3:0] d_disp1,
output [3:0] d_disp2,
output [3:0] d_disp3
    );
	
wire [6:0] d_out0, d_out1, d_out2, d_out3;
secure_router sr(.out0(d_out0), .out1(d_out1), .out2(d_out2), .out3(d_out3), .in(d_in));
wire clk;
wire [6:0] d_er0, d_er1, d_er2, d_er3;

CLKDiv C1(.CLK(clk_in), .CLKout(clk));

error_inject e0(.d_orig(d_out0), .erpos(d_in[5:4]), .d_error(d_er0),.clk(clk));
error_inject e1(.d_orig(d_out1), .erpos(d_in[5:4]), .d_error(d_er1),.clk(clk));
error_inject e2(.d_orig(d_out2), .erpos(d_in[5:4]), .d_error(d_er2),.clk(clk));
error_inject e3(.d_orig(d_out3), .erpos(d_in[5:4]), .d_error(d_er3),.clk(clk));

error_correct ec0(.d_hamm(d_er0), .d_disp(d_disp0),.clk(clk));
error_correct ec1(.d_hamm(d_er1), .d_disp(d_disp1),.clk(clk));
error_correct ec2(.d_hamm(d_er2), .d_disp(d_disp2),.clk(clk));
error_correct ec3(.d_hamm(d_er3), .d_disp(d_disp3),.clk(clk));
endmodule
