`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063

module secure_router(
    output reg [6:0] out0, 
    output reg [6:0] out1, 
    output reg [6:0] out2, 
    output reg [6:0] out3, 
    input [5:0] in
);

    wire [1:0] sel;
    assign sel = in[5:4];

    wire [6:0] y;

    Hamming_code_generator H(
        .in(in[3:0]),  
        .out(y)
    );

    always @* begin
        out0 = 7'b0;
        out1 = 7'b0;
        out2 = 7'b0;
        out3 = 7'b0;
        case (sel)
            2'b00: out0 = y; 
            2'b01: out1 = y; 
            2'b10: out2 = y; 
            2'b11: out3 = y;  
        endcase
    end
endmodule
