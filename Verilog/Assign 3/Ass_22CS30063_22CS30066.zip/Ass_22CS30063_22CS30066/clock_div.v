`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063
module CLKDiv(CLK, CLKout
    );

input CLK;
output reg CLKout;
reg [31:0] count=31'b0;
parameter DIV=10000000;
always @(posedge CLK) begin
if(count == DIV-1) begin
count <= 0;
CLKout <= ~CLKout;
end
else begin
count <= count+1;
end
end
endmodule