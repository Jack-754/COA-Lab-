`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063
module error_correct (
    input [6:0] d_hamm,
    output reg [3:0] d_disp,
	 input clk
);

    reg [2:0] erpos;
    reg [6:0] d_correction;

    always @(negedge clk) begin
        erpos[0] = d_hamm[0] ^ d_hamm[2] ^ d_hamm[4] ^ d_hamm[6]; 
        erpos[1] = d_hamm[1] ^ d_hamm[2] ^ d_hamm[5] ^ d_hamm[6]; 
        erpos[2] = d_hamm[3] ^ d_hamm[4] ^ d_hamm[5] ^ d_hamm[6];   
        erpos = erpos[0] + (erpos[1] << 1) + (erpos[2] << 2);
        d_correction = d_hamm;
        if (erpos != 3'b000) begin
            d_correction[erpos - 1] = ~d_hamm[erpos - 1];
        end
        d_disp[0] <= d_correction[2];
        d_disp[1] <= d_correction[4];
        d_disp[2] <= d_correction[5];
        d_disp[3] <= d_correction[6];
    end
   
endmodule
