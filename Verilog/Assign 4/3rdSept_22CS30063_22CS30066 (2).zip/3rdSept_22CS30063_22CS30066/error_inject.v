module error_inject(d_error,Serial_in, erpos, clk, strobe);
output [6:0] d_error;
input Serial_in,clk, strobe;
input [1:0] erpos;
reg [6:0] d_orig;
always @(negedge clk)begin
	if(strobe)begin
		d_orig[0] <=Serial_in;
		d_orig[1] <=d_orig[0];
		d_orig[2] <=d_orig[1];
		d_orig[3] <=d_orig[2];
		d_orig[4] <=d_orig[3];
		d_orig[5] <=d_orig[4];
		d_orig[6] <=d_orig[5];
	end
end
assign d_error[2] = d_orig[2] ^ (~erpos[1] & ~erpos[0]);
assign d_error[4] = d_orig[4] ^ (~erpos[1] & erpos[0]);
assign d_error[5] = d_orig[5] ^ (erpos[1] & ~erpos[0]);
assign d_error[6] = d_orig[6] ^ (erpos[1] & erpos[0]);

assign d_error[0] = d_orig[0];
assign d_error[1] = d_orig[1];
assign d_error[3] = d_orig[3];
endmodule