`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   15:39:55 09/03/2024
// Design Name:   secure_router
// Module Name:   C:/Users/Student/Desktop/CoaLab/Verilog/hamming/StrobeSignal/secure_router_test.v
// Project Name:  StrobeSignal
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: secure_router
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module secure_router_test;

	// Inputs
	reg [5:0] din;
	reg clock;

	// Outputs
	wire [15:0] dout;
	wire [6:0] orig, hamm1;

	// Instantiate the Unit Under Test (UUT)
	secure_router uut (
		.dout(dout), 
		.orig(orig),
		.hamm1(hamm1),
		.din(din), 
		.clock(clock)
	);
	
	initial begin
		// Initialize Inputs
		din = 6'b101000;
		clock = 0;
	
		// Wait 100 ns for global reset to finish
		#100;
        
		// Add stimulus here

	end
	
	always #20 clock = ~clock;
      
endmodule

