`timescale 1ns / 1ps

module secure_router(
    input [5:0] d_in,
    input clk,
    input rst,   
    output [15:0] d_out
);


    wire [6:0] d_hamm, error;
    wire [6:0] orig;
    wire [3:0] d_correct;

   
    reg Serial_in1, Serial_in2, strobe_inject, strobe_correct;
    integer cnt;

    assign d_hamm[2] = d_in[0];
    assign d_hamm[4] = d_in[1];
    assign d_hamm[5] = d_in[2];
    assign d_hamm[6] = d_in[3];
    assign d_hamm[0] = d_hamm[2] ^ d_hamm[4] ^ d_hamm[6];
    assign d_hamm[1] = d_hamm[2] ^ d_hamm[5] ^ d_hamm[6];
    assign d_hamm[3] = d_hamm[4] ^ d_hamm[5] ^ d_hamm[6];


    error_inject ei0(error,Serial_in1,d_in[5:4],clk,strobe_inject);

    error_correct ec0(d_correct,Serial_in2, clk, strobe_correct);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            cnt <= 0;
            strobe_inject <= 1;
            strobe_correct <= 0;
            Serial_in1 <= 0;
            Serial_in2 <= 0;
        end else begin
            if (cnt == 8) begin
                strobe_inject <= 0;
                strobe_correct <= 1;
            end else if (cnt == 16) begin
                strobe_correct <= 0;
            end
            if (cnt < 8) begin
                Serial_in1 <= d_hamm[7 - cnt];
            end else if (cnt < 16) begin
                Serial_in2 <= error[15 - cnt];
            end

            cnt <= cnt + 1;
            if (cnt >= 20) begin
                cnt <= 20;
            end
        end
    end

    assign d_out[15] = d_correct[3] & (d_in[5] & d_in[4]);
    assign d_out[14] = d_correct[2] & (d_in[5] & d_in[4]);
    assign d_out[13] = d_correct[1] & (d_in[5] & d_in[4]);
    assign d_out[12] = d_correct[0] & (d_in[5] & d_in[4]);

    assign d_out[11] = d_correct[3] & (d_in[5] & ~d_in[4]);
    assign d_out[10] = d_correct[2] & (d_in[5] & ~d_in[4]);
    assign d_out[9] = d_correct[1] & (d_in[5] & ~d_in[4]);
    assign d_out[8] = d_correct[0] & (d_in[5] & ~d_in[4]);

    assign d_out[7] = d_correct[3] & (~d_in[5] & d_in[4]);
    assign d_out[6] = d_correct[2] & (~d_in[5] & d_in[4]);
    assign d_out[5] = d_correct[1] & (~d_in[5] & d_in[4]);
    assign d_out[4] = d_correct[0] & (~d_in[5] & d_in[4]);

    assign d_out[3] = d_correct[3] & (~d_in[5] & ~d_in[4]);
    assign d_out[2] = d_correct[2] & (~d_in[5] & ~d_in[4]);
    assign d_out[1] = d_correct[1] & (~d_in[5] & ~d_in[4]);
    assign d_out[0] = d_correct[0] & (~d_in[5] & ~d_in[4]);

endmodule
