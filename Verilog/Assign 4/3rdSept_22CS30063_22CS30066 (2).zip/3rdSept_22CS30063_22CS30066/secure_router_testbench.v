`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   14:58:33 09/03/2024
// Design Name:   secure_router
// Module Name:   C:/Users/Student/Desktop/CoaLab/Verilog/hamming/StrobeSignal/secure_router_testbench.v
// Project Name:  StrobeSignal
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: secure_router
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module secure_router_testbench;

	// Inputs
	reg [5:0] din;
	reg clock;

	// Outputs
	wire [15:0] dout;

	// Instantiate the Unit Under Test (UUT)
	secure_router uut (
		.dout(dout), 
		.din(din), 
		.clock(clock)
	);

	// Clock generation
	always #20 clock = ~clock; // 50 MHz clock (10 ns period)

	// Initial block for stimulus
	initial begin
		// Initialize Inputs
		din = 6'b000000;
		clock = 0;

		// Wait 100 ns for global reset to finish
		#100;

		// Apply test stimuli
		din = 6'b001011;
		#20; // Wait for 20 ns

		din = 6'b110101;
		#20; // Wait for 20 ns

		din = 6'b010110;
		#20; // Wait for 20 ns

		// Add more stimulus if needed

		// End simulation after a certain time
		#100;
		$finish;
		
	end

endmodule
