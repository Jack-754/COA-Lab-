module error_correct(d_out, Serial_in, clk, strobe);
	input Serial_in , clk, strobe;
	output wire [3:0] d_out;
	reg [6:0] d_hamm;
	wire [2:0] erpos;
	always @(negedge clk)
		begin
		if(strobe) begin
			d_hamm[0]<=Serial_in;
			d_hamm[1]<=d_hamm[0];
			d_hamm[2]<=d_hamm[1];
			d_hamm[3]<=d_hamm[2];
			d_hamm[4]<=d_hamm[3];
			d_hamm[5]<=d_hamm[4];
			d_hamm[6]<=d_hamm[5];
		end
	end
assign erpos[0] = d_hamm[0] ^ d_hamm[2] ^ d_hamm[4] ^ d_hamm[6];
assign erpos[1] = d_hamm[1] ^ d_hamm[2] ^ d_hamm[5] ^ d_hamm[6];
assign erpos[2] = d_hamm[3] ^ d_hamm[4] ^ d_hamm[5] ^ d_hamm[6];

assign d_out[0] = d_hamm[2] ^ (~erpos[2] & erpos[1] & erpos[0]);
assign d_out[1] = d_hamm[4] ^ (erpos[2] & ~erpos[1] & erpos[0]);
assign d_out[2] = d_hamm[5] ^ (erpos[2] & erpos[1] & ~erpos[0]);
assign d_out[3] = d_hamm[6] ^ (erpos[2] & erpos[1] & erpos[0]);

endmodule

