`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063

module error_inject (
    input data_in,
	 input strobe,
    input [1:0] erpos,
    output reg [6:0] d_error,
	 input clk,
	 input [3:0] i
);

reg [6:0] d_orig;
always @(negedge strobe) begin
	d_orig <= (d_orig << 1) | (data_in);
    d_error <= d_orig;
	 if(i>=14) begin
		d_error[erpos] <= ~d_error[erpos];
	end
end
endmodule
