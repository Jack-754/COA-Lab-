`timescale 1ns / 1ps
// Group 29
// Devanshu Agrawal 22CS30066
// More Aayush Babasaheb 22CS30063


module top_wrapper(
input clk_in,
input [5:0] d_in,
output [3:0] d_disp0,
output [3:0] d_disp1,
output [3:0] d_disp2,
output [3:0] d_disp3,
input rst
    );
	
CLKDiv C1(.CLK(clk_in), .CLKout(clk));

wire [3:0] d_disp3;
wire [6:0] d_out0, d_out1, d_out2, d_out3;
reg d0,d1,d2,d3;
reg d4,d5,d6,d7;
reg [3:0] j;
reg [3:0] i;
reg strobe1,strobe2;
wire [6:0] d_er0, d_er1, d_er2, d_er3;
secure_router sr(.out0(d_out0), .out1(d_out1), .out2(d_out2), .out3(d_out3), .in(d_in));

always @(posedge clk) begin
	if(rst) begin
		i <= 4'b0000;
		strobe1 <= 0;
		j <= 4'b0000;
		strobe2 <= 0;
	end
	
	else if(i<14) begin
		d0 <= d_out0[i/2];
		d1 <= d_out1[i/2];
		d2 <= d_out2[i/2];
		d3 <= d_out3[i/2];
		strobe1 <= ~strobe1;
		i<=i+1;
	end
	else if(j<14) begin
		d4 <= d_er0[j/2];
		d5 <= d_er1[j/2];
		d6 <= d_er2[j/2];
		d7 <= d_er3[j/2];
		strobe2 <= ~strobe2;
		j<=j+1;
	end
end
error_inject e0(.data_in(d0),.strobe(strobe1), .erpos(d_in[5:4]), .d_error(d_er0),.clk(clk),.i(i));
error_inject e1(.data_in(d1),.strobe(strobe1), .erpos(d_in[5:4]), .d_error(d_er1),.clk(clk),.i(i));
error_inject e2(.data_in(d2),.strobe(strobe1), .erpos(d_in[5:4]), .d_error(d_er2),.clk(clk),.i(i));
error_inject e3(.data_in(d3),.strobe(strobe1), .erpos(d_in[5:4]), .d_error(d_er3),.clk(clk),.i(i));

error_correct ec0(.data_in(d4),.strobe(strobe2), .d_disp(d_disp0),.clk(clk));
error_correct ec1(.data_in(d5),.strobe(strobe2), .d_disp(d_disp1),.clk(clk));
error_correct ec2(.data_in(d6),.strobe(strobe2), .d_disp(d_disp2),.clk(clk));
error_correct ec3(.data_in(d7),.strobe(strobe2), .d_disp(d_disp3),.clk(clk));
endmodule
