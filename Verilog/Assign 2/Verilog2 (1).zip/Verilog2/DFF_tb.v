`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   14:29:47 08/21/2024
// Design Name:   DFF
// Module Name:   C:/Users/Student/Desktop/caua 2024/verilog/Tutorial_2/DFF_tb.v
// Project Name:  Tutorial_2
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: DFF
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module DFF_tb;

	// Inputs
	reg D;
	reg CLK;
	reg res;

	// Outputs
	wire Q;

	// Instantiate the Unit Under Test (UUT)
	DFF uut (
		.D(D), 
		.CLK(CLK), 
		.res(res), 
		.Q(Q)
	);

	initial begin
		// Initialize Inputs
		D = 0;
		CLK = 0;
		res = 0;

		// Wait 100 ns for global reset to finish
		forever
			begin
			
			#5 CLK = ~CLK;
			#10 D = ~Q;
			#10 $monitor($time "      ")
			end
        
		// Add stimulus here

	end
      
endmodule

