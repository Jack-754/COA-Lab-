`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    14:53:40 08/21/2024 
// Design Name: 
// Module Name:    CLKDiv 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module CLKDiv(CLK, CLKout
    );
	 
input CLK;
output reg CLKout;
reg [31:0] count=31'b0;
parameter DIV=100000000;
always @(posedge CLK) begin
if(count == DIV-1) begin
		count <= 0;
		CLKout <= ~CLKout;
	end
else begin
	count <= count+1;
	end
end
endmodule
