`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    14:12:56 08/21/2024 
// Design Name: 
// Module Name:    Mux2_1 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Mux2_1(sel,a,b,out);

input sel,a,b;
output out;

wire Nsel,t1,t2;

not G1(Nsel,sel);
and G2(t1,Nsel,a);
and G3(t2,sel,b);

or G4(out,t1,t2);
endmodule
