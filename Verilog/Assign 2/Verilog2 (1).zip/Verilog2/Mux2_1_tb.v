`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   14:15:35 08/21/2024
// Design Name:   Mux2_1
// Module Name:   C:/Users/Student/Desktop/caua 2024/verilog/Tutorial_2/Mux2_1_tb.v
// Project Name:  Tutorial_2
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Mux2_1
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Mux2_1_tb;

	// Inputs
	reg sel;
	reg a;
	reg b;

	// Outputs
	wire out;

	// Instantiate the Unit Under Test (UUT)
	Mux2_1 uut (
		.sel(sel), 
		.a(a), 
		.b(b), 
		.out(out)
	);

	initial begin
		$monitor($time, "		sel = %d, out = %b \n", sel, out);
		// Initialize Inputs
		sel = 0;
		a = 0;
		b = 1;

		// Wait 100 ns for global reset to finish
		#100;
		
		sel = 1;
		a = 0;
		b = 1;

		// Wait 100 ns for global reset to finish
		#100;
		// Add stimulus here

	end
      
endmodule

