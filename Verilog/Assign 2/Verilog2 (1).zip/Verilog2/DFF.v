`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    14:23:53 08/21/2024 
// Design Name: 
// Module Name:    DFF 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module DFF(D,CLK,res,Q);
	input wire D,CLK,res;
	output reg Q;	
	always @(posedge CLK or posedge res)
	begin
		if(res)
			begin
				Q <= 1'b0;
			end
		else
			begin
				Q <= D;
			end
	end
endmodule
