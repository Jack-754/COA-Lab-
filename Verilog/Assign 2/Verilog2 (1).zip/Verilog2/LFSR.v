`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    14:34:51 08/21/2024 
// Design Name: 
// Module Name:    LFSR 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//

// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module LFSR(sel,res,CLK,  seed, state);
input wire sel;
input wire res;
input wire CLK;
input [3:0] seed;
output [3:0] state;
wire t1, w[3:0];
wire CLKout;
CLKDiv clock(.CLK(CLK), .CLKout(CLKout));

xor G1(t1,state[0],state[1]);

Mux2_1 M1(.sel(sel), .out(w[3]), .a(seed[3]), .b(t1));
DFF D1(.CLK(CLKout),.res(res),.D(w[3]),.Q(state[3]));

Mux2_1 M2(.sel(sel), .out(w[2]), .a(seed[2]), .b(state[3]));
DFF D2(.CLK(CLKout),.res(res),.D(w[2]),.Q(state[2]));

Mux2_1 M3(.sel(sel), .out(w[1]), .a(seed[1]), .b(state[2]));
DFF D3(.CLK(CLKout),.res(res),.D(w[1]),.Q(state[1]));

Mux2_1 M4(.sel(sel), .out(w[0]), .a(seed[0]), .b(state[1]));
DFF D4(.CLK(CLKout),.res(res),.D(w[0]),.Q(state[0]));
endmodule
