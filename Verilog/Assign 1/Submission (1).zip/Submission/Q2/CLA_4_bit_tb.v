`timescale 1ns / 1ps

module CLA_4_bit_tb;

	reg [3:0] a;
	reg [3:0] b;
	reg cin;

	wire [3:0] s;
	wire cout;

	CLA_4_bit uut ( 
		.s(s), 
		.cout(cout), 
		.a(a), 
		.b(b), 
		.cin(cin)
	);

	initial begin
		$monitor($time, "		a = %d, b = %d, cin = %b, sum = %d, cout = %b \n", a, b, cin, s, cout);
		
		a = 0;
		b = 0;
		cin = 0;

		#100;
        
		a = 5;
		b = 1;
		cin = 0;
		
		#100;
		
		a = 3;
		b = 2;
		cin = 1;
		
		#100;
		
		a = 11;
		b = 1;
		cin = 0;
		
		#100;
		
		a = 12;
		b = 3;
		cin = 0;
		
		#100;
		
		a = 15;
		b = 1;
		cin = 0;
		
		#100;
		
		a = 11;
		b = 12;
		cin = 0;
		
		#100;

	end
      
endmodule

