`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/07/2024 05:52:57 PM
// Design Name: 
// Module Name: divide_module
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module divide_module(
output reg [31:0] out,
input [31:0] a,
input [31:0] b
    );
always@(*)begin
    if(b==0)begin
        out = 32'hFFFFFFFF;
    end
    else begin
        out = a/b;            
    end
end
endmodule
