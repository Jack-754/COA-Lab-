`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/09/2024 10:48:54 PM
// Design Name: 
// Module Name: wrap
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module wrap(
output [5:0] out,
input [5:0] a,
input [5:0] b,
input [3:0] func
    );

wire [31:0] alu_out;

ALU alu_inst (
    .out(alu_out),
    .func(func),
    .a({26'b0, a}),  
    .b({26'b0, b})  
);

assign out = alu_out[5:0];

endmodule
