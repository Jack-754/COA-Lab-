`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/07/2024 01:27:24 PM
// Design Name: 
// Module Name: ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ALU(
output [31:0] out,
input [3:0] func,
input [31:0] a,
input [31:0] b
    );
wire [31:0] buses [15:0];
wire [31:0] const_4;
wire sel1;
wire sel2;
wire [31:0] b_;
wire [31:0] b_1;
wire [31:0] b_2;
wire [31:0] b_3;
assign const_4 = 4;

//for mux between b and const 4
assign sel1 = ((func[3]) & (func[2]) & (~func[1]) & (func[0])) |    
              ((func[3]) & (func[2]) & (func[1]) & (~func[0]));
MUX_2to1 MX2to1 (.out(b_), .sel(sel1), .a(const_4), .b(b));

//finding 2's complement of b_
complement_module cm2(.out(b_1), .a(b_));
add_one ao(.out(b_2), .a(b_1));

//mux between b_ and 2's complement of b
assign sel2 = ((~func[3]) & (~func[2]) & (~func[1]) & (func[0])) | 
              ((func[3]) & (func[2]) & (func[1]) & (~func[0]));
MUX_2to1 MX2to1_2(.out(b_3), .sel(sel2), .a(b_2), .b(b_));

//add, subtract, A+4, A-4
wire [31:0] common;

add_module adm(.out(common), .cin(1'b0),.a(a), .b(b_3));
assign buses[0] = common;
assign buses[1] = common;
assign buses[13] = common;
assign buses[14] = common;

//a*b
multiply_module mm(.out(buses[2]), .a(a), .b(b));

//a/b
divide_module dm(.out(buses[3]), .a(a), .b(b));

//a&b
and_module am(.out(buses[4]), .a(a), .b(b));

//a|b
or_module om(.out(buses[5]), .a(a), .b(b));

//a^b
xor_module xm(.out(buses[6]), .a(a), .b(b));

//~a
complement_module cm(.out(buses[7]), .a(a));

//a
assign buses[8] = a;

//b
assign buses[9] = b;

//sll
sll_module sll(.Y(buses[10]), .A(a[7:0]), .B(b[7:0]));

//slr
slr_module slr(.Y(buses[11]), .A(a[7:0]), .B(b[7:0]));

//sar
sar_module sar(.Y(buses[12]), .A(a[7:0]), .B(b[7:0]));

//hamm(a)
hamm hm(.out(buses[15]), .a(a[7:0]));


assign out = buses[func];
endmodule
