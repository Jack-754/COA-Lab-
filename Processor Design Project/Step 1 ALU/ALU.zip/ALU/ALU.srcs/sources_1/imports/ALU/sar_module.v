module sar_module (
    input [7:0] A,
    input [7:0] B,
    output [31:0] Y
);
    wire more_than_8;
    or o1(more_than_8, B[3],B[4],B[5],B[6],B[7]);
    
    wire T[7:0];
    mux8_1 m1(.y(T[0]),.d(A[7:0]),.sel(B[2:0]));
    mux8_1 m2(.y(T[1]),.d({{1{A[7]}},A[7:1]}),.sel(B[2:0]));
    mux8_1 m3(.y(T[2]),.d({{2{A[7]}},A[7:2]}),.sel(B[2:0])); 
    mux8_1 m4(.y(T[3]),.d({{3{A[7]}},A[7:3]}),.sel(B[2:0])); 
    mux8_1 m5(.y(T[4]),.d({{4{A[7]}},A[7:4]}),.sel(B[2:0])); 
    mux8_1 m6(.y(T[5]),.d({{5{A[7]}},A[7:5]}),.sel(B[2:0])); 
    mux8_1 m7(.y(T[6]),.d({{6{A[7]}},A[7:6]}),.sel(B[2:0])); 
    mux8_1 m8(.y(T[7]),.d({8{A[7]}}),.sel(B[2:0]));

    mux2to1 mux1(.y(Y[0]),.d0(T[0]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux2(.y(Y[1]),.d0(T[1]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux3(.y(Y[2]),.d0(T[2]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux4(.y(Y[3]),.d0(T[3]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux5(.y(Y[4]),.d0(T[4]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux6(.y(Y[5]),.d0(T[5]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux7(.y(Y[6]),.d0(T[6]),.d1(A[7]),.sel(more_than_8));
    mux2to1 mux8(.y(Y[7]),.d0(T[7]),.d1(A[7]),.sel(more_than_8));
    assign Y[31:8] = 28'b0;
endmodule