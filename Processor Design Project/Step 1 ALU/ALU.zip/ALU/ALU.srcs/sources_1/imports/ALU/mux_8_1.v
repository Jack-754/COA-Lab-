module mux8_1 (
    output wire y, 
    input wire [7:0] d, 
    input wire [2:0] sel
);
    wire y0, y1, y2, y3, y4, y5;

    mux2to1 mux0 (.d0(d[0]), .d1(d[1]), .sel(sel[0]), .y(y0));
    mux2to1 mux1 (.d0(d[2]), .d1(d[3]), .sel(sel[0]), .y(y1));
    mux2to1 mux2 (.d0(d[4]), .d1(d[5]), .sel(sel[0]), .y(y2));
    mux2to1 mux3 (.d0(d[6]), .d1(d[7]), .sel(sel[0]), .y(y3));

    mux2to1 mux4 (.d0(y0), .d1(y1), .sel(sel[1]), .y(y4));
    mux2to1 mux5 (.d0(y2), .d1(y3), .sel(sel[1]), .y(y5));

    mux2to1 mux6 (.d0(y4), .d1(y5), .sel(sel[2]), .y(y));

endmodule