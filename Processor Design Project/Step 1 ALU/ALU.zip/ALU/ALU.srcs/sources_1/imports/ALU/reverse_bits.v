module reverse_bits (
    output [7:0] Y,
    input [7:0] B
);

assign Y[0] = B[7];
assign Y[1] = B[6];
assign Y[2] = B[5];
assign Y[3] = B[4];
assign Y[4] = B[3];
assign Y[5] = B[2];
assign Y[6] = B[1];
assign Y[7] = B[0];

endmodule