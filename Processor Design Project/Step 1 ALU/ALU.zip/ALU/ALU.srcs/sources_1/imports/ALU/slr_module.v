module slr_module (
    input [7:0] A,
    input [7:0] B,
    output [31:0] Y
);
    wire more_than_8;
    or o1(more_than_8, B[3],B[4],B[5],B[6],B[7]);
    wire more_than_8_not;
    not n1(more_than_8_not,more_than_8);
    wire T[7:0];
    mux8_1 m1(.y(T[0]),.d(A[7:0]),.sel(B[2:0]));
    mux8_1 m2(.y(T[1]),.d({1'b0,A[7:1]}),.sel(B[2:0]));
    mux8_1 m3(.y(T[2]),.d({2'b0,A[7:2]}),.sel(B[2:0])); 
    mux8_1 m4(.y(T[3]),.d({3'b0,A[7:3]}),.sel(B[2:0])); 
    mux8_1 m5(.y(T[4]),.d({4'b0,A[7:4]}),.sel(B[2:0])); 
    mux8_1 m6(.y(T[5]),.d({5'b0,A[7:5]}),.sel(B[2:0])); 
    mux8_1 m7(.y(T[6]),.d({6'b0,A[7:6]}),.sel(B[2:0])); 
    mux8_1 m8(.y(T[7]),.d({7'b0,A[7]}),.sel(B[2:0]));

    and a1(Y[0],more_than_8_not,T[0]);
    and a2(Y[1],more_than_8_not,T[1]);
    and a3(Y[2],more_than_8_not,T[2]);
    and a4(Y[3],more_than_8_not,T[3]);
    and a5(Y[4],more_than_8_not,T[4]);
    and a6(Y[5],more_than_8_not,T[5]);
    and a7(Y[6],more_than_8_not,T[6]);
    and a8(Y[7],more_than_8_not,T[7]);  
    assign Y[31:8] = 28'b0;
endmodule