`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/09/2024 09:54:54 PM
// Design Name: 
// Module Name: adder_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module adder_tb;
    reg [31:0] a;
    reg [31:0] b;
    reg [3:0] func;
    wire [31:0] out;

    // Instantiate the ALU module
    ALU uut (
        .out(out),
        .func(func),
        .a(a),
        .b(b)
    );

    // Test procedure
    initial begin
        // Test case 1: Add small numbers (buses[0])
        a = 32'h00000002;  // a = 2
        b = 32'h00000005;  // b = 5
        func = 4'b0000;    // Function select for addition
        #10;               // Wait for 10 time units
        $display("Output (buses[0]): %0d", $signed(out));

        // Test case 2: Add small numbers (buses[1])
        func = 4'b0001;    // Function select for addition (same as func[0] since buses[1] = buses[0])
        #10;               // Wait for 10 time units
        $display("Output (buses[1]): %0d", $signed(out));

        // Test case 3: Add with carry across 16-bit boundary
        a = 32'h0000FFFF;  // a = 65535 (maximum for lower 16 bits)
        b = 32'h00000001;  // b = 1 (to cause carry into upper 16 bits)
        func = 4'b0000;    // Function select for addition
        #10;               // Wait for 10 time units
        $display("Output (Carry across 16-bit boundary): %0d", $signed(out));

        // Test case 4: Large addition with potential carry across 16-bit boundary
        a = 32'hFFFF0000;  // a = large number with upper 16 bits filled
        b = 32'h0000FFFF;  // b = large number with lower 16 bits filled
        func = 4'b0000;    // Function select for addition
        #10;               // Wait for 10 time units
        $display("Output (Large addition with carry): %0d", $signed(out));

        // Test case 5: Add with constant 4 (buses[13])
        a = 32'h00000002;  // a = 2
        func = 4'b1101;    // Function select for adding 4 to a
        #10;               // Wait for 10 time units
        $display("Output (buses[13]): %0d", $signed(out));

        // Test case 6: Subtract 4 (buses[14])
        a = 32'h00000006;  // a = 6
        func = 4'b1110;    // Function select for subtracting 4 from a
        #10;               // Wait for 10 time units
        $display("Output (buses[14]): %0d", $signed(out));

        // Test case 7: Add large numbers without carry
        a = 32'h7FFFFFFF;  // a = large positive number
        b = 32'h00000001;  // b = 1
        func = 4'b0000;    // Function select for addition
        #10;               // Wait for 10 time units
        $display("Output (Large addition without carry): %0d", $signed(out));

        $stop;             // Stop the simulation
    end
endmodule