`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/08/2024 02:51:03 PM
// Design Name: 
// Module Name: add_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module add_tb;
    reg [31:0] a;
    reg [31:0] b;
    reg [3:0] func;
    wire [31:0] out;

    // Instantiate the ALU module
    ALU uut (
        .out(out),
        .func(func),
        .a(a),
        .b(b)
    );

    // Test procedure
    initial begin
        // Test case 1: Add (buses[0])
        a = 2;  // a = 2
        b = 5;  // b = 5
        func = 4'b0000;    // Function select for addition
        #10;               // Wait for 10 time units
        $display("Output (buses[0]): %0d", $signed(out));

        // Test case 2: Add (buses[1])
        func = 4'b0001;    // Function select for addition (same as func[0] since buses[1] = buses[0])
        #10;               // Wait for 10 time units
        $display("Output (buses[1]): %0d", $signed(out));

        // Test case 3: Add with constant 4 (buses[13])
        func = 4'b1101;    // Function select for adding 4 to a
        #10;               // Wait for 10 time units
        $display("Test case 3: Add 4");
        $display("Output (buses[13]): %0d", $signed(out));

        // Test case 4: Subtract 4 (buses[14])
        func = 4'b1110;    // Function select for subtracting 4 from a
        #10;               // Wait for 10 time units
        $display("Test case 4: Subtract 4");
        $display("Output (buses[14]): %0d", $signed(out));

        $stop;             // Stop the simulation
    end
endmodule
