`timescale 1ns / 1ps

module shift_tb;

    // Inputs to the ALU
    reg [3:0] func;
    reg [3:0] a;
    reg [3:0] b;
    
    // Output from the ALU
    wire [3:0] out;

    // Instantiate the ALU
    wrap uut (
        .out(out),
        .func(func),
        .a(a),  // Zero extend 'a' to 32 bits
        .b(b)   // Zero extend 'b' to 32 bits
    );

    // Test vectors
    initial begin
        // Initialize inputs
        a = 4'b1111;  // Set 'a' to 15 (4-bit)
        b = 4'b0001;  // Set 'b' to 1 (4-bit)

        // Test SLL (func = 4'b1010)
        func = 4'b1010; // SLL operation
        #10;
        $display("SLL Operation: a = %b, b = %0d, out = %b", a, b, out);

        // Test SLR (func = 4'b1011)
        func = 4'b1011; // SLR operation
        #10;
        $display("SLR Operation: a = %b, b = %0d, out = %b", a, b, out);

        // Test SAR (func = 4'b1100)
        func = 4'b1100; // SAR operation
        #10;
        $display("SAR Operation: a = %b, b = %0d, out = %b", a, b, out);

        // Test with different values for 'a' and 'b'
        a = 4'b1110;  // Set 'a' to 14 (4-bit)
        b = 4'b0010;  // Set 'b' to 2 (4-bit)

        // Test SLL with new inputs
        func = 4'b1010; // SLL operation
        #10;
        $display("SLL Operation: a = %b, b = %0d, out = %b", a, b, out);

        // Test SLR with new inputs
        func = 4'b1011; // SLR operation
        #10;
        $display("SLR Operation: a = %b, b = %0d, out = %b", a, b, out);

        // Test SAR with new inputs
        func = 4'b1100; // SAR operation
        #10;
        $display("SAR Operation: a = %b, b = %0d, out = %b", a, b, out);

        $finish;
    end
endmodule
