`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/09/2024 03:04:59 PM
// Design Name: 
// Module Name: ALU_hamm_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module ALU_hamm_tb;

    // Inputs
    reg [31:0] a;
    reg [31:0] b;
    reg [3:0] func;

    // Outputs
    wire [31:0] out;

    // Instantiate the ALU
    ALU uut (
        .out(out),
        .func(func),
        .a(a),
        .b(b)
    );

    initial begin
        // Initialize inputs
        a = 0;
        b = 0;
        func = 4'b0000;

        // Apply test vectors for hamm module
        // Test Case 1: Hamming weight of a = 8'b00000000 (expected output: 0)
        #10 a = 32'b00000000_00000000_00000000_00000000; func = 4'b1111;
        #10;
        if (out == 0)
            $display("Test Case 1 Passed %d", out);
        else
            $display("Test Case 1 Failed. Output: %d", out);

        // Test Case 2: Hamming weight of a = 8'b00000001 (expected output: 1)
        #10 a = 32'b00000000_00000000_00000000_00000001; func = 4'b1111;
        #10;
        if (out == 1)
            $display("Test Case 2 Passed %d", out);
        else
            $display("Test Case 2 Failed. Output: %d", out);

        // Test Case 3: Hamming weight of a = 8'b11111111 (expected output: 8)
        #10 a = 32'b00000000_00000000_00000000_11111111; func = 4'b1111;
        #10;
        if (out == 8)
            $display("Test Case 3 Passed %d", out);
        else
            $display("Test Case 3 Failed. Output: %d", out);

        // Test Case 4: Hamming weight of a = 8'b10101010 (expected output: 4)
        #10 a = 32'b00000000_00000000_00000000_10101010; func = 4'b1111;
        #10;
        if (out == 4)
            $display("Test Case 4 Passed %d", out);
        else
            $display("Test Case 4 Failed. Output: %d", out);

        // Stop simulation
        #10;
        $stop;
    end

endmodule
