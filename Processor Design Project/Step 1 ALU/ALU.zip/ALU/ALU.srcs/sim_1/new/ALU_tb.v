`timescale 1ns / 1ps

module ALU_tb;

    // Inputs to the ALU
    reg [31:0] a;
    reg [31:0] b;
    reg [3:0] func;

    // Output from the ALU
    wire [31:0] out;

    // Instantiate the ALU module
    ALU uut (
        .out(out),
        .func(func),
        .a(a),
        .b(b)
    );

    // Initialize inputs and apply test cases
    initial begin
        // Initialize inputs
        a = 32'b0;
        b = 32'b0;
        func = 4'b0;

        // Apply test vectors and check results

        // Test case 1: a & b
        a = 32'hF0F0F0F0;  // Example value for a
        b = 32'h0F0F0F0F;  // Example value for b
        func = 4'd4;       // Select the AND operation
        #10;               // Wait for 10 time units
        $display("func = %d, a & b = %h, out = %h", func, a & b, out);
        // Expected output: a & b

        // Test case 2: a | b
        func = 4'd5;       // Select the OR operation
        #10;               // Wait for 10 time units
        $display("func = %d, a | b = %h, out = %h", func, a | b, out);
        // Expected output: a | b

        // Test case 3: a ^ b
        func = 4'd6;       // Select the XOR operation
        #10;               // Wait for 10 time units
        $display("func = %d, a ^ b = %h, out = %h", func, a ^ b, out);
        // Expected output: a ^ b

        // Test case 4: ~a
        func = 4'd7;       // Select the complement operation
        #10;               // Wait for 10 time units
        $display("func = %d, ~a = %h, out = %h", func, ~a, out);
        // Expected output: ~a

        // Test case 5: Pass-through a
        func = 4'd8;       // Select the a operation
        #10;               // Wait for 10 time units
        $display("func = %d, a = %h, out = %h", func, a, out);
        // Expected output: a

        // Test case 6: Pass-through b
        func = 4'd9;       // Select the b operation
        #10;               // Wait for 10 time units
        $display("func = %d, b = %h, out = %h", func, b, out);
        // Expected output: b

        // End of test
        $finish;
    end

endmodule
