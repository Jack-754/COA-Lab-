`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/10/2024 08:03:44 AM
// Design Name: 
// Module Name: wrap_full_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module wrap_full_tb; // Testbench signals
    reg [3:0] a;
    reg [3:0] b;
    reg [3:0] func;
    wire [3:0] out;

    // Instantiate the ALU wrapper module
    wrap uut (
        .out(out),
        .a(a),
        .b(b),
        .func(func)
    );

    // Test sequence
    initial begin
        // Initialize inputs
        a = 4'b0000;
        b = 4'b0000;
        func = 4'b0000;

        // Apply test vectors

        // Test Addition (func = 0000)
        a = 4'b0011; // 3
        b = 4'b0010; // 2
        func = 4'b0000;
        #10;
        $display("Addition: %d + %d = %d", a, b, out);

        // Test Subtraction (func = 0001)
        func = 4'b0001;
        #10;
        $display("Subtraction: %d - %d = %0d", a, b, $signed(out));

        // Test A + 4 (func = 1101)
        func = 4'b1101;
        #10;
        $display("A + 4: %d + 4 = %d", a, out);

        // Test A - 4 (func = 1110)
        func = 4'b1110;
        #10;
        $display("A - 4: %d - 4 = %0d", a, $signed(out));

        // Test Multiplication (func = 0010)
        func = 4'b0010;
        #10;
        $display("Multiplication: %d * %d = %d", a, b, out);

        // Test Division (func = 0011)
        func = 4'b0011;
        #10;
        $display("Division: %d / %d = %d", a, b, out);

        // Test AND (func = 0100)
        func = 4'b0100;
        #10;
        $display("AND: %b & %b = %b", a, b, out);

        // Test OR (func = 0101)
        func = 4'b0101;
        #10;
        $display("OR: %b | %b = %b", a, b, out);

        // Test XOR (func = 0110)
        func = 4'b0110;
        #10;
        $display("XOR: %b ^ %b = %b", a, b, out);

        // Test NOT A (func = 0111)
        func = 4'b0111;
        #10;
        $display("NOT A: ~%b = %b", a, out);

        // Test passing A (func = 1000)
        func = 4'b1000;
        #10;
        $display("Pass A: %b", out);

        // Test passing B (func = 1009)
        func = 4'b1001;
        #10;
        $display("Pass B: %b", out);

        // Test SLL (func = 1010)
        a = 4'b0011; // Example input for SLL
        b = 4'b0001; // Shift by 1
        func = 4'b1010;
        #10;
        $display("SLL: %b << %d = %b", a, b, out);

        // Test SLR (func = 1011)
        func = 4'b1011;
        #10;
        $display("SLR: %b >> %d = %b", a, b, out);

        // Test SAR (func = 1100)
        func = 4'b1100;
        #10;
        $display("SAR: %b >>> %d = %b", a, b, out);

        // Test Hamming code (func = 1111)
        a = 4'b1011; // Example input for Hamming code
        func = 4'b1111;
        #10;
        $display("Hamming Code: H(%b) = %b", a, out);

        $finish; // End simulation
    end

endmodule
