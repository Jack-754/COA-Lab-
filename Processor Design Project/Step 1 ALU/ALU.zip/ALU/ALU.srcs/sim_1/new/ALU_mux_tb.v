`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/07/2024 10:03:17 PM
// Design Name: 
// Module Name: ALU_mux_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ALU_mux_tb;
    // Inputs
    reg [31:0] a;
    reg [31:0] b;
    reg [3:0]sel;

    // Outputs
    wire [31:0] out;

    // Instantiate the Unit Under Test (UUT)
    ALU uut (
        .out(out), 
        .func(sel), 
        .a(a), 
        .b(b)
    );

    // Initialize Inputs
    initial begin
        // Initialize inputs
        a = 32'd10;
        b = 32'd20;
        sel = 0;

        // Wait for global reset
        #100;

        sel = 0;
        #10;
        $display("%d * %d", out, b);

        sel = 1;
        #10;
        $display("%d * %d", out, b);

        a = 32'd30;
        b = 32'd40;
        sel = 0;
        #10;
        $display("%d * %d", out, b);

        a = 32'd50;
        b = 32'd60;
        sel = 1;
        #10;
        $display("%d * %d", out, b);

        $finish;
    end


endmodule