`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/10/2024 08:32:53 PM
// Design Name: 
// Module Name: control_path_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module testbench();
    reg [2:0] control;
    reg clk, clr;
    wire [31:0] result;

    // Instantiate the control path module
    control_path cp(.control(control), .clk(clk), .clr(clr), .result(result));

    // Task to display all register values
    task display_registers;
        begin
            $display("Time: %0t | R1: %h | R2: %h | R3: %h | R4: %h | R5: %h | R6: %h | R7: %h", 
                     $time, cp.reg_bank.w[1], cp.reg_bank.w[2], cp.reg_bank.w[3],
                     cp.reg_bank.w[4], cp.reg_bank.w[5], cp.reg_bank.w[6], cp.reg_bank.w[7]);
        end
    endtask

    initial begin
        // Initialize the clock and clear
        clk = 0;
        clr = 1;
        #5 clr = 0;

        // Initialize registers with values
        cp.reg_bank.w[1] = 32'h00000005; // R1 = 5
        cp.reg_bank.w[2] = 32'h00000003; // R2 = 3
        cp.reg_bank.w[3] = 32'h00000007; // R3 = 7
        cp.reg_bank.w[4] = 32'h00000002; // R4 = 2
        cp.reg_bank.w[5] = 32'h00000001; // R5 = 1
        cp.reg_bank.w[6] = 32'h00000000; // R6 = 0
        cp.reg_bank.w[7] = 32'h00000004; // R7 = 4

        // Display initial register values
        $display("Initial Register Values:");
        display_registers();

        // Test each operation and display register values after each
        control = 3'b000; #10; // R1 = R2 + R3
        $display("After Control 000 (R1 = R2 + R3):");
        display_registers();

        control = 3'b001; #10; // R4 = R1 - R5
        $display("After Control 001 (R4 = R1 - R5):");
        display_registers();

        control = 3'b010; #10; // R2 = R1 << R2
        $display("After Control 010 (R2 = R1 << R2):");
        display_registers();

        control = 3'b011; #10; // R7 = R1 >> R2
        $display("After Control 011 (R7 = R1 >> R2):");
        display_registers();

        control = 3'b100; #10; // R6 = R1 * R2
        $display("After Control 100 (R6 = R1 * R2):");
        display_registers();

        control = 3'b101; #10; // R1 = R1 AND R2
        $display("After Control 101 (R1 = R1 AND R2):");
        display_registers();

        control = 3'b110; #10; // R3 = R2
        $display("After Control 110 (R3 = R2):");
        display_registers();

        control = 3'b111; #10; // R6 = 0
        $display("After Control 111 (R6 = 0):");
        display_registers();

        // Finish the simulation
        $finish;
    end

    // Clock generation
    always #5 clk = ~clk;
endmodule

