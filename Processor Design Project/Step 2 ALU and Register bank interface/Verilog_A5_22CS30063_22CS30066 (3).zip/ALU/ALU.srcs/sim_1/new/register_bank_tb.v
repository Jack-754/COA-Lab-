`timescale 1ns / 1ps

module tb_register_bank;

    // Testbench signals
    reg [2:0] sr1;
    reg [2:0] sr2;
    reg [2:0] dr;
    reg [31:0] drd;
    reg clk;
    reg clr;
    
    wire [31:0] srd1;
    wire [31:0] srd2;
    
    // Instantiate the register_bank
    register_bank uut (
        .srd1(srd1),
        .srd2(srd2),
        .sr1(sr1),
        .sr2(sr2),
        .dr(dr),
        .drd(drd),
        .clk(clk),
        .clr(clr)
    );

    // Clock generation
    always begin
        #5 clk = ~clk; // 10ns clock period
    end

    // Test sequence
    initial begin
        // Initialize signals
        clk = 0;
        clr = 0;
        sr1 = 3'b000;
        sr2 = 3'b001;
        dr = 3'b000;
        drd = 32'h12345678;

        // Apply reset
        clr = 1;
        #10 clr = 0; // Release reset

        // Test storing values
        dr = 3'b001;
        drd = 32'hAABBCCDD;
        #10; // Wait for 1 clock cycle
        
        // Verify values
        sr1 = 3'b001; // Read from register 1
        sr2 = 3'b000; // Read from register 0 (should be zero)
        #10;

        // Check the output values
        $display("At time %t: srd1 = %h, srd2 = %h", $time, srd1, srd2);

        // Test more values
        dr = 3'b010;
        drd = 32'h87654321;
        #10;

        // Read from different registers
        sr1 = 3'b010; // Read from register 2
        sr2 = 3'b001; // Read from register 1
        #10;

        // Check the output values
        $display("At time %t: srd1 = %h, srd2 = %h", $time, srd1, srd2);

        // End the simulation
        $finish;
    end

endmodule
