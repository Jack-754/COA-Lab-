`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/11/2024 02:20:51 PM
// Design Name: 
// Module Name: cp_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// Output of the code is observed over the completed signal statement that is available on.

// Initialised values -- Initialized for each computation (by design.)

// R0 - 0 (constant zero)
// R1 - 25 
// R2 - 3 
// R3 - 5 
// R4 - 8 
// R5 - 9 
// R6 - 10 
// R7 - 11 


 

module integrate_tb();
    reg [2:0] c;
    reg clk;
    reg rst;
    integrate cp(.c(c), .clk(clk),.rst(rst));
    initial begin
        $display("--------------------C=000: ADD--------------------");
        rst = 1'b1;
        c = 3'b000;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=001: SUB--------------------");
        rst = 1'b1;
        c = 3'b001;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=010: left shift--------------------");
        rst = 1'b1;
        c = 3'b010;
        #10
        rst = 1'b0;
        #50
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=011: right shift--------------------");
        rst = 1'b1;
        c = 3'b011;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=100: Mul--------------------");
        rst = 1'b1;
        c = 3'b100;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=101: And--------------------");
        rst = 1'b1;
        c = 3'b101;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=110: Buf--------------------");
        rst = 1'b1;
        c = 3'b110;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
        $display("--------------------C=111: set 0--------------------");
        rst = 1'b1;
        c = 3'b111;
        #10
        rst = 1'b0;
        #90
        $display("--------------------COMPLETED--------------------");
    end
    initial begin
        clk = 1'b0;
        forever begin
            #10 clk = ~clk;
        end
    end 
endmodule
