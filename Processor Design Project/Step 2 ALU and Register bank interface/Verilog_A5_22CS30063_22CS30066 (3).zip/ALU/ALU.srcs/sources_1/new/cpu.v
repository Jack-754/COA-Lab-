`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/09/2024 10:48:54 PM
// Design Name: 
// Module Name: wrap
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module control_path(
input [2:0] c,
input clk,
output reg [2:0] sr1,
output reg [2:0] sr2,
output reg [2:0] dr,
output reg clr,
output reg [3:0]func,
input rst
);

reg  state;
localparam S0 = 1'd0; 
localparam S1 = 1'd1;

reg nextstate;
always @(negedge clk)begin
case(state)
    S0: begin
        clr <=1;
        dr <=0;
        nextstate <=S1;
    end
    S1: begin
        clr <= 0;
        case(c)
            3'b000: begin
                sr1<=3'b010;
                sr2<=3'b011;
                dr<=3'b001;
                func<=4'b0000;
            end
            3'b001: begin
                sr1<=3'b001;
                sr2<=3'b101;
                dr<=3'b100;
                func<=4'b0001;
            end
            3'b010: begin
                sr1<=3'b001;
                sr2<=3'b010;
                dr<=3'b010;
                func<=4'b1010;
            end 
            3'b011: begin
                sr1<=3'b001;
                sr2<=3'b010;
                dr<=3'b111;
                func<=4'b1011;
            end 
            3'b100: begin
                sr1<=3'b001;
                sr2<=3'b010;
                dr<=3'b110;
                func<=4'b0010;
            end 
            3'b101: begin
                sr1<=3'b001;
                sr2<=3'b010;
                dr<=3'b001;
                func<=4'b0100;
            end 
            3'b110: begin
                sr1<=3'b010;
                sr2<=3'b000;
                dr<=3'b011;
                func<=4'b1000;
            end 
            3'b111: begin
                sr1<=3'b000;
                sr2<=3'b000;
                dr<=3'b110;
                func<=4'b1000;
            end  
            endcase
            nextstate <=S1; 
        end
    endcase    
end

always @(negedge clk or posedge rst) begin
    if(rst) begin 
        dr<=3'b000;
        state <= 1'b0;
    end
    else begin 
        state <= nextstate;
    end
end

endmodule