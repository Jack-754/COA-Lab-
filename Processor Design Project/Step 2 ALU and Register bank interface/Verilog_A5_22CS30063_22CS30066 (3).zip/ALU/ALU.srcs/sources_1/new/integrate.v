`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/11/2024 01:37:20 PM
// Design Name: 
// Module Name: integrate
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module integrate(
input [2:0] c,
input clk,
input rst
    );
    wire [2:0] sr1, sr2, dr;
    wire [31:0] srd1, srd2, drd;
    wire [3:0] func;
    wire clr;
    ALU kalu(.out(drd), .func(func), .a(srd1), .b(srd2));
    control_path cp(.c(c), .clk(clk), .sr1(sr1), .sr2(sr2), .dr(dr), .func(func), .clr(clr), .rst(rst));
    register_bank rb(.srd1(srd1), .srd2(srd2), .sr1(sr1), .sr2(sr2), .dr(dr), .drd(drd), .clk(clk), .clr(clr));
endmodule
