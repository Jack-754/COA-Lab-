`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/10/2024 05:34:20 PM
// Design Name: 
// Module Name: register_bank
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module register_bank(
output reg [31:0] srd1,
output reg [31:0] srd2,
input  [2:0] sr1,
input [2:0] sr2,
input [2:0] dr,
input [31:0] drd,
input clk,
input clr
    );
wire [31:0] w [7:0];
wire [7:0] decoded;

decoder_8bit db(.out(decoded), .in(dr));

PIPO_module R0(.out(w[0]), .in(0), .ld(1'b1), .clr(clr), .clk(clk), .din(32'b0));
PIPO_module R1(.out(w[1]), .in(drd), .ld(decoded[1]), .clr(clr), .clk(clk), .din(25));
PIPO_module R2(.out(w[2]), .in(drd), .ld(decoded[2]), .clr(clr), .clk(clk), .din(3));
PIPO_module R3(.out(w[3]), .in(drd), .ld(decoded[3]), .clr(clr), .clk(clk), .din(5));
PIPO_module R4(.out(w[4]), .in(drd), .ld(decoded[4]), .clr(clr), .clk(clk), .din(8));
PIPO_module R5(.out(w[5]), .in(drd), .ld(decoded[5]), .clr(clr), .clk(clk), .din(9));
PIPO_module R6(.out(w[6]), .in(drd), .ld(decoded[6]), .clr(clr), .clk(clk), .din(10));
PIPO_module R7(.out(w[7]), .in(drd), .ld(decoded[7]), .clr(clr), .clk(clk), .din(11));

always @(negedge clk)begin
srd1 <= w[sr1];
srd2 <= w[sr2];
end

always @(w[0] or w[1] or w[2] or w[3] or w[4] or w[5] or w[6] or w[7]) begin
    $display("Time: %0t | Register values:", $time);
    $display("R0: %0d", $signed(w[0]));
    $display("R1: %0d", $signed(w[1]));
    $display("R2: %0d", $signed(w[2]));
    $display("R3: %0d", $signed(w[3]));
    $display("R4: %0d", $signed(w[4]));
    $display("R5: %0d", $signed(w[5]));
    $display("R6: %0d", $signed(w[6]));
    $display("R7: %0d", $signed(w[7]));
end


endmodule
