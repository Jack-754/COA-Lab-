`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/10/2024 05:48:27 PM
// Design Name: 
// Module Name: decoder_8bit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder_8bit(
    output [7:0] out,
    input [2:0] in
    );

    wire in0_n, in1_n, in2_n;

    not (in0_n, in[0]);
    not (in1_n, in[1]);
    not (in2_n, in[2]);

    and (out[0], in0_n, in1_n, in2_n); 
    and (out[1], in[0], in1_n, in2_n); 
    and (out[2], in0_n, in[1], in2_n); 
    and (out[3], in[0], in[1], in2_n); 
    and (out[4], in0_n, in1_n, in[2]); 
    and (out[5], in[0], in1_n, in[2]); 
    and (out[6], in0_n, in[1], in[2]); 
    and (out[7], in[0], in[1], in[2]); 

endmodule

